# S2-0 テストキット（手元 PC 用）

VivecraftBedrockBridge の Stage 2 最初の確認（S2-0）を、通常ネットワークの PC で行うための一式です。

## このテストで確認すること

1. Geyser 拡張（ViveBridgeExtension）が最後まで起動し、カスタム定義とプロパティ29個を登録できるか
2. 防具立てが統合版にスポーンするたびに拡張が反応し、UUID を照合できるか
3. UUID が一致した防具立てだけ、定義がカスタム側に差し替わるか（通常の防具立てには影響しない＝対照実験）
4. サーバー再起動後も、拡張が再登録されて同じ動作をするか
5. `/geyser reload` が接続中の統合版セッションに何をするか

**見た目はまだ変わりません。** リソースパックは S2-1 で入れるので、このテストの判定はすべてサーバーログで行います。

## 用意するもの（ダウンロード）

| もの | 入手先 |
|---|---|
| JDK 25（Temurin） | https://adoptium.net/temurin/releases/?version=25 から Windows x64 の JDK 25 をインストール |
| Paper 26.3-259 | https://fill-data.papermc.io/v1/objects/5efbc6ce4b8e128bfa77fa0d3e79132dfeaaab827abe0f87dd930535e5e489fd/paper-26.3-259.jar |
| Geyser-Spigot 2.12.1 build 1307 | https://download.geysermc.org/v2/projects/geyser/versions/2.12.1/builds/1307/downloads/spigot （ファイル名は `Geyser-Spigot.jar` に変える） |

キット同梱: `ViveBridgeExtension.jar`（テスト対象）、`floodgate-spigot.jar`（2.2.5 build 141、本番と同じ）、`mannequins.txt`（空ファイル）

## フォルダ構成

作業用フォルダ（例: `C:\mc-test`）に次を作ります。

```
mc-test/
  paper-26.3-259.jar
  plugins/
    Geyser-Spigot.jar
    floodgate-spigot.jar
    Geyser-Spigot/
      extensions/
        ViveBridgeExtension.jar
```

`Geyser-Spigot` フォルダと `extensions` フォルダは、初回起動後に自動でできる部分もあります。先にフォルダを作って jar を入れておいても大丈夫です。

## 手順

### 1. 初回起動と EULA

`mc-test` フォルダでターミナルを開き、JDK 25 の java で起動します（`java -version` で 25 系が出ることを確認。違うバージョンが出る場合は JDK 25 の `java.exe` をフルパスで指定）。

```
java -Xmx2G -jar paper-26.3-259.jar nogui
```

生成された `eula.txt` の `eula=false` を `eula=true` に書き換えて、もう一度起動します。ワールド生成が終わり `Done` と出たら、コンソールで `stop` して止めます。

### 2. Geyser の設定（Floodgate 方式に変更）

`plugins/Geyser-Spigot/config.yml` を開き、`auth-type` を `floodgate` に書き換えます（本番サーバーと同じ設定）。統合版のポートは既定の `19132` のままで OK です（ローカルテスト用）。

### 3. 起動して拡張の登録ログを確認

再び起動し、コンソール（と `logs/latest.log`）に次の3行が出ることを確認します。

```
[ViveBridge-S2-0] extension initialized
[ViveBridge-S2-0] registered custom entity definition vivecraftbedrockbridge:vr_avatar
[ViveBridge-S2-0] registered 29 float properties
```

Geyser 本体もエラーなく起動完了していることが大事です（ALTERNA の VM ではここで止まりました。通常ネットワークなら通るはず）。

### 4. 参加する

- Java 版: いつものアカウント（RK3_Vivecraft）で `localhost` に参加
- 統合版: スマホから、同じ Wi-Fi 内でサーバーアドレス＝PC のローカル IP、ポート `19132` で参加（Floodgate なので Java アカウントなしで入れます。名前の頭に `.` が付きます）

### 5. 対照実験（通常の防具立て）

統合版から見える場所で、Java 版かコンソールから防具立てを出します。

```
/summon minecraft:armor_stand ~ ~ ~
```

ログに次のような行が出て、`match=false` であることを確認します。これが「関係ないエンティティには触らない」ことの証明になります。

```
[ViveBridge-S2-0] spawn uuid=xxxxxxxx-.... entityId=... type=... match=false
```

**この行の uuid をメモしてください。** 次の手順で使います。

### 6. UUID 照合と定義の差し替え

1. サーバーを止めずに、`plugins/Geyser-Spigot/extensions/` の中にある拡張用データフォルダ（`VivecraftBedrockBridge` という名前のフォルダができているはずです。無ければ同名フォルダを作ってください）に、同梱の `mannequins.txt` を置き、手順5の uuid を1行だけ書きます。
   - `mannequins.txt` はスポーンのたびに読み直されるので、**サーバーの再起動は不要**です。
2. スマホ（統合版）を一度切断し、再参加します。防具立てが再びスポーンするので、ログに次が出れば成功です。

```
[ViveBridge-S2-0] spawn uuid=（同じuuid） ... match=true
[ViveBridge-S2-0] definition swapped for uuid=（同じuuid）
```

統合版側の見た目が変わらなくても、この段階では正常です（見た目は S2-1）。

### 7. `/geyser reload` の挙動確認

スマホを接続したまま、コンソールで `/geyser reload` を実行し、次を記録してください。

- スマホは切断されるか、そのまま遊べるか
- コンソールにエラーが出るか（出たらその文面）

### 8. 再起動チェック

コンソールで `stop` → もう一度起動し、手順3の登録ログ3行が再び出ることと、手順6の `match=true` が（スマホ再参加で）再現することを確認します。

## チェックリスト

- [ ] 拡張の登録ログ3行が出た
- [ ] Geyser がエラーなく起動完了した
- [ ] 通常の防具立てで `match=false`（対照実験）
- [ ] mannequins.txt 登録後、同じ防具立てで `match=true` ＋ `definition swapped`
- [ ] `/geyser reload` の挙動を記録した
- [ ] 再起動後も登録ログと match が再現した

## 終わったら

**`logs/latest.log` を丸ごとおるたなっちに送ってください。** ログを見て3人（おるたなっち・しるふぁ・ミーナ）で結果を確認します。
途中でエラーになって進めなくなっても、そのままログを送ってくれれば大丈夫です。
